export { 
  SearchBasicSchema, 
  SearchAdvancedSchema, 
  SearchRequestSchema,
  SaveSearchSchema,
  type SearchBasicDTO,
  type SearchAdvancedDTO,
  type SearchRequestDTO,
  type SaveSearchDTO,
} from '../discovery/search.dto.js';
