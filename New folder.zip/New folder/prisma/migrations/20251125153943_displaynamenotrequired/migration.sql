-- AlterTable
ALTER TABLE "profiles" ALTER COLUMN "displayName" DROP NOT NULL;
