-- AlterTable
ALTER TABLE "plans" ADD COLUMN     "category" TEXT NOT NULL DEFAULT 'subscription';
